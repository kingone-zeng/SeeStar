(function () {
    'use strict';

    function renderHomeState(data) {
        var shared = data ? { data: data } : (typeof loadShareStore === 'function' ? loadShareStore() : null);
        var hasSave = !!(shared && shared.data);
        var status = document.getElementById('homeSaveStatus');
        var mainRole = document.getElementById('homeMainRole');
        if (status) status.textContent = hasSave ? '导入成功' : '未导入';
        if (mainRole) {
            mainRole.textContent = hasSave && typeof getArchiveMainRoleName === 'function'
                ? getArchiveMainRoleName(shared.data)
                : '—';
        }
        return hasSave;
    }

    function setMessage(message, isError) {
        var element = document.getElementById('homeImportMessage');
        if (!element) return;
        element.textContent = message;
        element.classList.toggle('is-error', !!isError);
        element.classList.toggle('is-success', !isError && message === '导入成功');
    }

    function buildMeta(result, file) {
        // 安卓+v2.1.44 富元信息：渠道/列/行/文件名/时间一起带上，
        // 网页各模块（洗髓/装备/恒山/家园/鬼市）按渠道与版本选规则
        return {
            version: result.version,
            platform: result.platform || '',
            channel: result.channel || (String(result.platform || '').toLowerCase() === 'oversea' ? '国际服' : ''),
            format: result.format || 'json',
            columns: result.columns || null,
            row: result.row || null,
            fileName: (file && file.name) || '',
            fileLastModified: (file && Number(file.lastModified)) || null,
            importedAt: Date.now()
        };
    }

    async function handleImport(file) {
        if (!file) return;
        if (typeof _importFeedback === 'function') _importFeedback(true);
        setMessage('正在解析存档…', false);
        try {
            // 统一入口：.yanyu 明文容器 / 明文 JSON / 旧格式导出工具文件
            var result = await decryptSaveFile(file);
            if (typeof saveShareStore !== 'function' || !saveShareStore(result.data, buildMeta(result, file))) {
                throw new Error('浏览器无法保存存档，请检查本地存储权限或剩余空间');
            }
            renderHomeState(result.data);
            setMessage('导入成功', false);
        } catch (error) {
            var message = error && error.message ? String(error.message) : '';
            if (message === 'SAVE_FILE_UNSUPPORTED') setMessage('存档失败', true);
            else if (message === 'PLAIN_JSON_INVALID') setMessage('不是有效的存档文件（缺少必要字段）', true);
            else if (message && message.trim()) setMessage(message, true);
            else setMessage('存档导入失败，请检查文件是否完整且未改名', true);
        } finally {
            if (typeof _importFeedback === 'function') _importFeedback(false);
        }
    }

    function initializeHome() {
        renderHomeState();

        // 自动加载通道（由工具 webserve 的 write_last_import 生成 last-import.js）
        //   新版：window.__latestYanyuB64（密文，本地解密；必要时询问授权码）
        //   兼容：window.__latestPlainSave（工具解密好的明文 json）
        var autoYanyu = (typeof window !== 'undefined' && window.__latestYanyuB64) ? window.__latestYanyuB64 : '';
        var autoSave = (typeof window !== 'undefined' && window.__latestPlainSave) ? window.__latestPlainSave : null;
        if (autoYanyu && typeof decryptSaveBytes === 'function' && typeof _b64ToBytes === 'function') {
            decryptSaveBytes(_b64ToBytes(autoYanyu),
                (typeof window !== 'undefined' && window.__latestYanyuName) || '', true)
                .then(function (result) {
                    if (typeof saveShareStore === 'function' && saveShareStore(result.data,
                        buildMeta(result, { name: (typeof window !== 'undefined' && window.__latestYanyuName) || '' }))) {
                        renderHomeState();
                    }
                })
                .catch(function (err) {
                    var message = err && err.message ? String(err.message) : '';
                    if (message === 'YANYU_CODE_WRONG') setMessage('授权码不对，请重新导入存档', true);
                    else if (message === '已取消导入') setMessage('已取消导入，可手动选择存档', true);
                    else setMessage(message || '自动导入失败，请手动选择存档', true);
                    if (typeof console !== 'undefined' && console.warn) {
                        console.warn('[last-import]', err && err.message ? err.message : err);
                    }
                });
        } else if (autoSave && typeof saveShareStore === 'function') {
            var payload = autoSave.data || autoSave;
            var ok = saveShareStore(payload, {
                version: (autoSave && autoSave.version) || '明文',
                platform: (autoSave && autoSave.platform) || '',
                channel: '',
                format: 'plain-json',
                importedAt: Date.now()
            });
            if (ok) renderHomeState();
        }

        var input = document.getElementById('saveFileInput');
        if (input) input.addEventListener('change', function (event) {
            var file = event.target.files && event.target.files[0];
            handleImport(file);
            event.target.value = '';
        });

        var resetButton = document.getElementById('btnResetWebsite');
        if (resetButton) resetButton.addEventListener('click', function () {
            if (typeof clearWebsiteState === 'function') clearWebsiteState();
            renderHomeState();
            setMessage('重置成功', false);
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initializeHome);
    } else {
        initializeHome();
    }
    setTimeout(function () {
        if (typeof prewarmSql === 'function') prewarmSql();
    }, 200);
})();
