# 烟雨观星 · 存档工具（安卓 + iOS 合并版 v2.7.0）

> 由 iOS v2.6 全量功能 + 安卓本地存档（local）恢复合并而来（2026-10-27）。
> 支持：国服 + 国际服；安卓（本地 dat.db / 模拟器拉取 / 抓包）+ iOS（ProxyPin 抓包）。

## 功能一览

- **导入方式**
  - `local`：本地存档 —— 我有 dat.db 文件直接给路径 / 从模拟器、设备上拉取（游戏要在运行）
  - `capture`：抓包导入 —— ProxyPin / mitmproxy 导出的 `.har`（安卓、iOS 通用）
  - `rebuild`：明文 dat.json 重建初版 dat.db
- **输出**（默认 `output/` 或 `%LOCALAPPDATA%\yanyu-guanxing\output\`）
  - `<平台><区服>区-<用户名>/<时间戳>/dat.json` 解密后的完整存档
  - `<平台><区服>区-<用户名>/<时间戳>/dat.db` 初版存档（可推回设备 / 导入自动精灵等游戏工具）
  - `<平台><区服>区-<用户名>/<时间戳>/dat.meta.json` 元信息（账号/版本/密钥/来源）
  - 平台按真实账号命名：安卓 = `android`，iOS = `ios`
- **网页版**（自动拉起，也可手动 `python -m yyjh serve`）
  - 洗髓模拟 / 装备模拟 / 恒山模拟 / 角色面板 / **角色状态** / 自动模拟 / 家园派遣 / 鬼市千宝阁 / 恒山游货郎
  - 存档自动载入；也支持手动导入 `.yanyu` 本地导出 / 明文 JSON / 旧格式 dat.db（含 1.8 / 1.8.3 / 1.9 / 2.0 / 2.1 解析版本选择）
- **密钥机制**
  - 抓包自带 realKey（就是外层密钥），自动记入 `keys.local.json`，同账号下次解本地存档不用再扫内存
  - 游戏更新后内层密钥缺失时，向导可就地「挖密钥」（游戏开着，工具全自动）

## 使用方法

### 方式一：源码运行（需要 Python 3.10+）

```bat
pip install -r requirements.txt
python run.py
```

不带参数即进入向导；或直接用命令：

```bat
python -m yyjh capture <抓包.har>       抓包导入
python -m yyjh local <dat.db>           本地存档导入
python -m yyjh local                    去模拟器/设备上拉取
python -m yyjh rebuild <dat.json>       明文 JSON 重建
python -m yyjh serve                    网页版服务
```

参数参考：`--outdir` 输出目录、`--no-db` 不写 dat.db、`--no-json` 不写 JSON、
`--report` 额外流程报告、`--pkg huawei` 指定渠道、`--mem off` 跳过内存步骤等。

### 方式二：打包 exe

```bat
build.bat
```

产出单文件 `烟雨观星.exe`（自带 Python 环境 + 网页版；密钥/存档统一在
`%LOCALAPPDATA%\yanyu-guanxing\`）。首次运行若弹 SmartScreen，点“更多信息 → 仍要运行”即可。

### 安卓存档（重点）

1. 模拟器上把游戏打开、进一次角色（密钥只存在于游戏进程内存里）
2. 方案 A：`python run.py` → 选「local」→「我有存档文件」拖入 dat.db
   方案 B：选「local」→「从模拟器/设备上拉取」→ 工具自动 adb 取存档并挖外层密钥
   方案 C：游戏里先点「上传」再抓包导出 `.har`，走 capture 导入
3. 完成：打开网页版模拟，`dat.db` 可推回设备

### iOS 抓包

1. 安装免费开源抓包工具 ProxyPin（AppStore 直接安装）
2. ProxyPin 点开始抓包（无需开启 HTTPS 代理）
3. 进游戏主页面：未登录先登录；为防止丢数据先点左下角[上传]，再点[下载]
4. 停止抓包 → 右上角三点 → 视图导出 → 选 HAR 格式
5. HAR 传到电脑，拖到 `python run.py` 向导（或 `python -m yyjh capture <file.har>`）

## 目录结构

```
yyjh/       Python 核心（config/core/game/capture/localdb/memscan/unpack/reverse）
web/        网页版（恒山/家园/鬼市/角色状态等模块）
keys.json   官方固定密钥表（只读真源；个人命中的密钥写入 keys.local.json）
run.py      向导入口；build.bat 打包 exe
```

## 与旧版（v1.1.0 安卓）的关系

- 沿用安卓存档读取全链路：local 模式、dat.db 输出、模拟器 adb 拉取、多区服 area 过滤
- 新增 iOS v2.6 全部能力：恒山/家园/鬼市/恒山游货郎等网页模块、完整存档
  （download 响应，含 Rnds 世界种子）、国际服（qwmyk 魔数）、bundled adb、exe 打包
- 网页 save_decrypt 合二为一：旧格式（1.8~2.1 dat.db/.yanyu）+ 新版本地导出
  （YANYUPL1 明文容器）+ 明文 JSON 全部支持

<!-- v2.7 合并版（安卓 local + iOS 2.6 全量） -->
